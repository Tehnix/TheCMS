<?php
# Redirect to cgi-bin
Header( "HTTP/1.1 301 Moved Permanently" ); 
Header( "Location: cgi-bin/index.py" );
# If that fails, try meta refresh, and a fallback link
print '<html>
<head>
    <meta http-equiv="refresh" content="0; url=cgi-bin/index.py">
</head>
<body>
    <a href="cgi-bin/index.py">Go to index</a>
</body>
</html>';
?>