<?php
require("../settings.php");

print "PHP delen af MySQL db backup scriptet";
?>