--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `position` int(11) NOT NULL,
  `discussion` tinyint(1) NOT NULL DEFAULT '0',
  `display` tinyint(1) NOT NULL DEFAULT '1',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  `app` varchar(200) NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pages`
--

INSERT INTO pages VALUES("1","title","","0","0","1","1","","2011-09-19 20:07:07","0");
INSERT INTO pages VALUES("2","title","content","0","0","1","1","","2011-09-19 20:08:48","0");
INSERT INTO pages VALUES("3","title","content","1","0","1","1","other","2011-10-01 14:57:49","0");
INSERT INTO pages VALUES("4","title","content","2","1","1","1","","2011-09-19 20:09:08","0");
INSERT INTO pages VALUES("5","title","content","3","1","1","0","text","2011-09-19 20:10:18","0");
INSERT INTO pages VALUES("6","test","asdad","4","0","1","0","text","2011-10-12 18:19:43","0");
INSERT INTO pages VALUES("7","Okay ??????","hejsa &lt;3aaa","5","0","1","0","text","2011-10-12 18:24:49","0");
INSERT INTO pages VALUES("8","asdasd","","6","0","1","0","text","2011-10-12 19:39:19","0");
INSERT INTO pages VALUES("9","sadasd","","7","0","1","0","text","2011-10-12 19:39:22","0");



