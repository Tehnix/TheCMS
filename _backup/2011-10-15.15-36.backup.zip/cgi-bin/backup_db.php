<?php
require('../manage.php');
$filename = ROOT . '_backup/database/' . date("Y-m-d.H-i") . '.backup.sql';
$backup_db = $Database->backupDatabase('*', $filename);
if($backup_db){
	print 'The database has been backed up successfully !';
}
else{
	print 'Something went wrong while trying to backup the database, please try again <input class="old_backup_btn" type="button" value="Backup database !">';
}
?>