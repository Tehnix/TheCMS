<?php
/*
----- Instantiate class -----
$blog = new Blog;
----- To retrieve one blogpost -----
$post = $blog->getBlogPosts('LIMIT $num', $blogid);
$post['id'];
$post['title'];
$post['post'];
$post['category'];
$post['tags'];
$post['archive'];
$post['author_id'];
$post['author_name'];
$post['author_username'];
$post['author_email'];
$post['author_level'];
$post['date_posted'];
$post['discussion'];
$post['trash'];
----- To retrieve all blogposts -----
$blogposts = $blog->getBlogPosts() or $blog->getBlogPosts('LIMIT $num')
foreach ($blogposts as $post)
{
	$post['id'];
	$post['title'];
	$post['post'];
	$post['category'];
	$post['tags'];
	$post['archive'];
	$post['author_id'];
	$post['author_name'];
	$post['author_username'];
	$post['author_email'];
	$post['author_level'];
	$post['date_posted'];
	$post['discussion'];
	$post['trash'];
}
----- To add blogposts -----
$addblogpost = $blog->addBlogPost(addslashes($title), addslashes($post), $author_id, $category, $tags, $discussion);
----- To update blogposts -----
$updateblogpost = $blog->updateBlogPost($updateId, $title, $post, $author_id, $category, $tags, $discussion);
*/
class Blog
{
	public $database;
	
	public function __construct(){
		global $Database;
		$this->database = $Database;
	}
	
	public function getBlogPosts( $inLimit=null, $inId=null, $inCategoryId=null, $inTagId=null, $inArchiveId=null){
		if(!empty($inId)){
			$posts = $this->database->fetchOne('blog_posts', array('id'=>$inId, 'trash'=>'0'));
			$posts['date_posted'] = date('F d, Y', strtotime($posts['date_posted']));
			$posts['category'] = $this->getCategory($post['id']);
			$posts['tags'] = $this->getTags($post['id']);
			$posts['archive'] = $this->getArchive($post['id']);
			$posts['comments_count'] = $this->database->count('blog_post_comments', array('blog_post_id'=>$inId));
			$author = $this->database->fetchOne('usersdb', array('id'=>$posts['author_id']));
			$posts['author_username'] = $author['username'];
			$posts['author_name'] = $author['first_name'] . ' ' . $author['last_name'];
			$posts['author_email'] = $author['email'];
			$posts['author_level'] = $author['userlevel'];
		}
		else{
			if (!empty($inTagId))
			{
				$posts = $this->database->execute('fetchall', 'SELECT blog_posts.* FROM blog_post_tags 
					LEFT JOIN (blog_posts) ON (blog_post_tags.blog_post_id = blog_posts.id) 
					WHERE blog_post_tags.tag_id = :inTagId 
					ORDER BY blog_posts.id DESC', array('inTagId'=>$inTagId));
			}
			else if (!empty($inCategoryId))
			{
				$posts = $this->database->execute('fetchall', 'SELECT blog_posts.* FROM blog_post_categories 
					LEFT JOIN (blog_posts) ON (blog_post_categories.blog_post_id = blog_posts.id) 
					WHERE blog_post_categories.category_id = :inCategoryId 
					ORDER BY blog_posts.id DESC', array('inCategoryId'=>$inCategoryId));
			}
			else if (!empty($inArchiveId))
			{
				$posts = $this->database->execute('fetchall', 'SELECT blog_posts.* FROM blog_post_archive 
					LEFT JOIN (blog_posts) ON (blog_post_archive.blog_post_id = blog_posts.id) 
					WHERE blog_post_archive.archive_id = :inArchiveId 
					ORDER BY blog_posts.id DESC', array('inArchiveId'=>$inArchiveId));
			}
			else{
				$posts = $this->database->fetchAll('blog_posts', array('trash'=>'0'), 'ORDER BY id DESC' . $inLimit);
			}
			for($i=0; $i<sizeof($posts); $i++){
				$posts[$i]['date_posted'] = date('F d, Y', strtotime($posts[$i]['date_posted']));
				$posts[$i]['category'] = $this->getCategory($posts[$i]['id']);
				$posts[$i]['tags'] = $this->getTags($posts[$i]['id']);
				$posts[$i]['archive'] = $this->getArchive($posts[$i]['id']);
				$posts[$i]['comments_count'] = $this->database->count('blog_post_comments', 
				array('blog_post_id'=>$posts[$i]['id']));
				$author = $this->database->fetchOne('usersdb', array('id'=>$posts[$i]['author_id']));
				$posts[$i]['author_username'] = $author['username'];
				$posts[$i]['author_name'] = $author['first_name'] . ' ' . $author['last_name'];
				$posts[$i]['author_email'] = $author['email'];
				$posts[$i]['author_level'] = $author['userlevel'];
			}
		}
		return $posts;
	}
	
	public function addBlogPost( $title, $post, $author_id, $category=null, $tags=null, $discussion=null ){
		// Check if basic values are submitted, else print error
		if(empty($title) || empty($post) || empty($author_id)) {
			return false;
		}
		else {
			$this->database->insert('blog_posts', array('title'=>$title, 'post'=>$post, 
			'author_id'=>$author_id, 'discussion'=>$discussion));
			
			$blogInsertId = $this->database->lastInsertId();
			
			$this->database->insert('_recent_activity', array('name'=>'blog', 'grouping'=>'blog'.date("Y-m-d"), 
			'action'=>'insert', 'additional'=>$title));
			// Adds the current action to the _recent_activity table
			/*
			$recentActivity = new dashboard;
			$recentActivity->RecentActivity("blog", "blog".date("Y-m-d"), "insert", $title);
			
			addArchive($blogInsertId);	
			addTags($tags, $blogInsertId);
			addCategory($category, $blogInsertId);
			*/
			
			return true;
		}
	}
	
	public function updateBlogPost( $id=null, $title=null, $post=null, $author_id=null, $category=null, $tags=null, $discussion=null ){
		if(empty($id) || empty($title) || empty($post) || empty($author_id)) {
			return false;
		}
		else {
			$this->database->update('blog_posts', array('title'=>$title, 'post'=>$post, 'author_id'=>$author_id, 
			'discussion'=>$discussion), array('id'=>$id));
			
			$blogInsertId = $this->database->lastInsertId();
			
			$this->database->insert('_recent_activity', array('name'=>'blog', 'grouping'=>'blog'.date("Y-m-d"), 
			'action'=>'update', 'additional'=>$title));
			// Adds the current action to the _recent_activity table
			/*
			$recentActivity = new dashboard;
			$recentActivity->RecentActivity("blog", "blog".date("Y-m-d"), "update", $title);
			
			addArchive($blogInsertId);	
			addTags($tags, $blogInsertId);
			addCategory($category, $blogInsertId);
			*/
			
			return true;
		}
	}
	
	public function addArchive( $insertid=null ){
		// create archive value from current Month and year and add to database
		$archive = Date('F y');

		$archive = $this->database->fetchOne('archive', array('name'=>$archive), 'ORDER BY id');
		$archiveId = $archive['id'];
		$archiveName = $archive['name'];
		
		if(!empty($archiveId)) {	
			$query = "SELECT COUNT(*) FROM blog_post_archive (blog_post_id, archive_id) WHERE 
			blog_post_id = '$insertid' AND archive_id = '$archiveId'";
			$result = mysql_query($query);
			$count = mysql_result($result, 0);
			
			if($count == 0) {
				$this->database->insert('blog_post_archive', array('blog_post_id'=>$insertid, 'archive_id'=>$archiveId));
			}
		}
		else {
			$this->database->insert('archive', array('name'=>$archive));

			$this->database->insert('blog_post_archive', array('blog_post_id'=>$insertid, 
			'archive_id'=>$this->database->lastInsertId()));
		}
	}

	public function getArchive( $inId ){
		$query = $this->database->execute('fetchall', 'SELECT archive.* FROM blog_post_archive 
			LEFT JOIN (archive) ON (blog_post_archive.archive_id = archive.id) 
			WHERE blog_post_archive.blog_post_id = :inId GROUP BY name', array('inId'=>$inId));
		$tmp_array = array();
		$IDArray = array();
		foreach($query as $item){
			array_push($tmp_array, $item["name"]);
			array_push($IDArray, $item["id"]);
		}
		if(empty($tmp_array) or $tmp_array[0] == ''){
			$array = '';
		}
		else{
			$array = implode(', ', $tmp_array);
		}
		
		return $array;
	}
	
	public function addCategory( $category, $insertid=null ){
		if(!empty($subCategory)) {
			$subCategory = mysql_real_escape_string($subCategory);
			// insert $subCategory into array if more categories?
			$subCategory = preg_split("/[\s]*[,][\s]*/", $subCategory);
			// in the meanwhile functions like tags
			foreach($subCategory as $arrayCategory) {
				$category = $this->database->fetchAll('categories', array('name'=>$arrayCategory), 'ORDER BY id');
				$categoryId = $category['id'];
				$categoryName = $category['name'];
				
				if(!empty($categoryId)) {
					$query = "SELECT COUNT(*) FROM blog_post_categories (blog_post_id, category_id) WHERE 
					blog_post_id = '$insertid' AND category_id = '$categoryId'";
					$result = mysql_query($query);
					$count = mysql_result($result, 0);
					
					if($count == 0) {
						$this->database->insert('blog_post_categories', array('blog_post_id'=>$insertid, 
						'category_id'=>$categoryId));
					}
				}
				else {
					$this->database->insert('categories', array('name'=>$arrayCategory));
					
					$this->database->insert('blog_post_categories', array('blog_post_id'=>$insertid, 
					'category_id'=>$this->database->lastInsertId()));
				}
					
			}
		}
	}
	
	public function getCategory( $inId ){
		$query = $this->database->execute('fetchall', 'SELECT categories.* FROM blog_post_categories 
			LEFT JOIN (categories) ON (blog_post_categories.category_id = categories.id) 
			WHERE blog_post_categories.blog_post_id = :inId GROUP BY name', array('inId'=>$inId));
		$tmp_array = array();
		$IDArray = array();
		foreach($query as $item){
			array_push($tmp_array, $item["name"]);
			array_push($IDArray, $item["id"]);
		}
		if(empty($tmp_array)){
			$array = '';
		}
		else{
			$array = implode(', ', $tmp_array);
		}
		
		return $array;
	}
	
	public function addTags( $tags, $insertid=null ){
		if(!empty($subTags)) {
			$subTags = mysql_real_escape_string($subTags);
			$subTags = preg_split("/[\s]*[,][\s]*/", $subTags);
			foreach($subTags as $arrayTags) {
				$tags = $this->database->fetchAll('tags', array('name'=>$arrayTags), 'ORDER BY id');
				$tagId = $tags['id'];
				$tagName = $tags['name'];
				
				if(!empty($tagId)) {
					$query = "SELECT COUNT(*) FROM blog_post_tags (blog_post_id, tag_id) WHERE blog_post_id = '$insertid' 
					AND tag_id = '$tagId'";
					$result = mysql_query($query);
					$count = mysql_result($result, 0);
					
					if($count == 0) {
						$this->database->insert('blog_post_tags', array('blog_post_id'=>$insertid, 
						'tag_id'=>$tagId));
					}
				}
				else {
					$this->database->insert('tags', array('name'=>$arrayTags));
					
					$this->database->insert('blog_post_tags', array('blog_post_id'=>$insertid, 
					'tag_id'=>$this->database->lastInsertId()));
				}
					
			}
		}
	}
	
	public function getTags( $inId ){
		$query = $this->database->execute('fetchall', 'SELECT tags.* FROM blog_post_tags 
			LEFT JOIN (tags) ON (blog_post_tags.tag_id = tags.id) 
			WHERE blog_post_tags.blog_post_id = :inId GROUP BY name', array('inId'=>$inId));
		$tmp_array = array();
		$IDArray = array();
		foreach($query as $item){
			array_push($tmp_array, $item["name"]);
			array_push($IDArray, $item["id"]);
		}
		if(empty($tmp_array)){
			$array = '';
		}
		else{
			$array = implode(', ', $tmp_array);
		}
		
		return $array;
	}
}
if($_POST['action'] == 'blog_addBlogPost'){
	$Blog = new Blog;
	$Blog->addBlogPost($_POST['blog_title'], $_POST['blog_post'], $session->id, 
					   $_POST['blog_category'], $_POST['blog_tags'], $_POST['blog_discussion']);
	header("Location: " . $_POST['referer'] . "");
}
if($_POST['action'] == 'blog_updateBlogPost'){
	$Blog = new Blog;
	$Blog->updateBlogPost($_POST['blog_id'], $_POST['blog_title'], $_POST['blog_post'], $session->id, 
					   $_POST['blog_category'], $_POST['blog_tags'], $_POST['blog_discussion']);
	header("Location: " . $_POST['referer'] . "");
}